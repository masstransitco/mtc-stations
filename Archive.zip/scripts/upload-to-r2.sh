#!/bin/bash

# Upload building tiles to Cloudflare R2
# This script uploads all tiles while preserving directory structure

BUCKET_NAME="mtc-buildings-tiles"
TILES_DIR="public/buildings/tiles"

echo "🚀 Starting upload of building tiles to R2..."
echo "📁 Source: $TILES_DIR"
echo "🪣 Bucket: $BUCKET_NAME"
echo ""

# Count total files
TOTAL_FILES=$(find "$TILES_DIR" -type f -name "*.json" | wc -l | tr -d ' ')
echo "📊 Total files to upload: $TOTAL_FILES"
echo ""

# Upload files in batches
COUNTER=0
BATCH_SIZE=100

find "$TILES_DIR" -type f -name "*.json" | while read -r file; do
  # Get relative path from tiles directory
  RELATIVE_PATH="${file#$TILES_DIR/}"

  # Upload to R2 with correct path
  wrangler r2 object put "$BUCKET_NAME/$RELATIVE_PATH" --file="$file" 2>&1 | grep -v "Uploading" || true

  COUNTER=$((COUNTER + 1))

  # Show progress every 100 files
  if [ $((COUNTER % BATCH_SIZE)) -eq 0 ]; then
    PERCENT=$((COUNTER * 100 / TOTAL_FILES))
    echo "⏳ Progress: $COUNTER/$TOTAL_FILES ($PERCENT%)"
  fi
done

echo ""
echo "✅ Upload complete!"
echo "🎉 Uploaded $TOTAL_FILES files to R2"
