#!/usr/bin/env node
/**
 * Building Tiling Script
 *
 * Splits converted building GeoJSON into zoom-based tiles for efficient loading.
 * Uses Web Mercator tile coordinates (z/x/y) similar to standard map tiles.
 *
 * Input: public/buildings/converted-buildings.json
 * Output: public/buildings/tiles/{z}/{x}/{y}.json
 */

import * as fs from 'fs';
import * as path from 'path';
import bbox from '@turf/bbox';
import booleanPointInPolygon from '@turf/boolean-point-in-polygon';
import { point } from '@turf/helpers';

interface ConvertedFeature {
  type: 'Feature';
  geometry: {
    type: 'Polygon' | 'MultiPolygon';
    coordinates: number[][][] | number[][][][];
  };
  properties: {
    OBJECTID: number;
    BUILDINGSTRUCTUREID: number;
    CATEGORY: string;
    height_m: number;
    color: string;
    [key: string]: any;
  };
}

interface TileCoordinate {
  z: number;
  x: number;
  y: number;
}

/**
 * Convert lat/lng to tile coordinates at a given zoom level
 */
function latLngToTile(lat: number, lng: number, zoom: number): { x: number; y: number } {
  const n = Math.pow(2, zoom);
  const x = Math.floor(((lng + 180) / 360) * n);
  const latRad = (lat * Math.PI) / 180;
  const y = Math.floor(((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) * n);
  return { x, y };
}

/**
 * Get tile bounds (lat/lng) from tile coordinates
 */
function tileToBounds(x: number, y: number, zoom: number): { north: number; south: number; east: number; west: number } {
  const n = Math.pow(2, zoom);
  const west = (x / n) * 360 - 180;
  const east = ((x + 1) / n) * 360 - 180;

  const northLatRad = Math.atan(Math.sinh(Math.PI * (1 - (2 * y) / n)));
  const southLatRad = Math.atan(Math.sinh(Math.PI * (1 - (2 * (y + 1)) / n)));

  const north = (northLatRad * 180) / Math.PI;
  const south = (southLatRad * 180) / Math.PI;

  return { north, south, east, west };
}

/**
 * Check if a building intersects with a tile
 */
function buildingIntersectsTile(feature: ConvertedFeature, tileBounds: ReturnType<typeof tileToBounds>): boolean {
  // Get building bounding box
  const buildingBbox = bbox(feature);
  const [minLng, minLat, maxLng, maxLat] = buildingBbox;

  // Quick rejection test: if bboxes don't overlap
  if (
    maxLng < tileBounds.west ||
    minLng > tileBounds.east ||
    maxLat < tileBounds.south ||
    minLat > tileBounds.north
  ) {
    return false;
  }

  return true;
}

/**
 * Get all tiles that a building intersects at a given zoom level
 */
function getBuildingTiles(feature: ConvertedFeature, zoom: number): TileCoordinate[] {
  const buildingBbox = bbox(feature);
  const [minLng, minLat, maxLng, maxLat] = buildingBbox;

  // Get tile range
  const minTile = latLngToTile(maxLat, minLng, zoom); // maxLat because Y is inverted
  const maxTile = latLngToTile(minLat, maxLng, zoom);

  const tiles: TileCoordinate[] = [];

  // Iterate through all tiles in range
  for (let x = minTile.x; x <= maxTile.x; x++) {
    for (let y = minTile.y; y <= maxTile.y; y++) {
      const tileBounds = tileToBounds(x, y, zoom);
      if (buildingIntersectsTile(feature, tileBounds)) {
        tiles.push({ z: zoom, x, y });
      }
    }
  }

  return tiles;
}

/**
 * Create tile index for efficient querying
 */
function createTileIndex(tileMap: Map<string, ConvertedFeature[]>): any {
  const index: any = {};

  for (const [tileKey, features] of tileMap.entries()) {
    const [z, x, y] = tileKey.split('/').map(Number);

    if (!index[z]) index[z] = {};
    if (!index[z][x]) index[z][x] = {};

    index[z][x][y] = {
      count: features.length,
      file: `tiles/${z}/${x}/${y}.json`
    };
  }

  return index;
}

/**
 * Main tiling function
 */
async function tileBuildings() {
  console.log('🗺️  Building Tiling Started');
  console.log('===========================\n');

  // Paths
  const inputPath = path.join(process.cwd(), 'public/buildings/converted-buildings.json');
  const outputDir = path.join(process.cwd(), 'public/buildings/tiles');
  const indexPath = path.join(process.cwd(), 'public/buildings/tile-index.json');

  // Check input file exists
  if (!fs.existsSync(inputPath)) {
    console.error('❌ Error: Input file not found at:', inputPath);
    console.error('   Please run convert-buildings.ts first');
    process.exit(1);
  }

  // Create output directory
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
    console.log('✅ Created output directory:', outputDir);
  }

  console.log('📖 Reading converted buildings...');
  const startTime = Date.now();

  const inputData = fs.readFileSync(inputPath, 'utf-8');
  const geojson = JSON.parse(inputData);
  const features: ConvertedFeature[] = geojson.features;

  console.log(`✅ Loaded ${features.length.toLocaleString()} buildings\n`);

  // Tile at zoom levels 15, 16, 17, 18
  // z15: ~4.9km per tile (city-wide view)
  // z16: ~2.4km per tile (district view)
  // z17: ~1.2km per tile (neighborhood view)
  // z18: ~610m per tile (street view)
  const zoomLevels = [15, 16, 17, 18];

  for (const zoom of zoomLevels) {
    console.log(`\n🔄 Processing zoom level ${zoom}...`);

    // Map to store tiles: "z/x/y" => features[]
    const tileMap = new Map<string, ConvertedFeature[]>();

    let processedCount = 0;
    const totalFeatures = features.length;

    for (const feature of features) {
      try {
        const tiles = getBuildingTiles(feature, zoom);

        for (const tile of tiles) {
          const tileKey = `${tile.z}/${tile.x}/${tile.y}`;

          if (!tileMap.has(tileKey)) {
            tileMap.set(tileKey, []);
          }

          tileMap.get(tileKey)!.push(feature);
        }

        processedCount++;

        // Progress update every 10k features
        if (processedCount % 10000 === 0) {
          const progress = ((processedCount / totalFeatures) * 100).toFixed(1);
          console.log(`   Progress: ${processedCount.toLocaleString()} / ${totalFeatures.toLocaleString()} (${progress}%)`);
        }
      } catch (error) {
        console.error(`⚠️  Warning: Failed to tile feature ${feature.properties.OBJECTID}:`, error);
      }
    }

    console.log(`   ✅ Created ${tileMap.size} tiles for zoom ${zoom}`);

    // Write tiles to disk
    console.log(`   💾 Writing tiles to disk...`);
    let tilesWritten = 0;

    for (const [tileKey, tileFeatures] of tileMap.entries()) {
      const [z, x, y] = tileKey.split('/');
      const tilePath = path.join(outputDir, z, x);
      const tileFile = path.join(tilePath, `${y}.json`);

      // Create directory if needed
      if (!fs.existsSync(tilePath)) {
        fs.mkdirSync(tilePath, { recursive: true });
      }

      // Create tile GeoJSON
      const tileGeoJSON = {
        type: 'FeatureCollection',
        tile: { z: Number(z), x: Number(x), y: Number(y) },
        count: tileFeatures.length,
        features: tileFeatures
      };

      // Write tile
      fs.writeFileSync(tileFile, JSON.stringify(tileGeoJSON));
      tilesWritten++;

      if (tilesWritten % 100 === 0) {
        console.log(`   Wrote ${tilesWritten} / ${tileMap.size} tiles`);
      }
    }

    console.log(`   ✅ Wrote all ${tilesWritten} tiles for zoom ${zoom}`);
  }

  // Create tile index
  console.log('\n📇 Creating tile index...');

  const allTiles = new Map<string, ConvertedFeature[]>();

  // Read all tiles to create index
  for (const zoom of zoomLevels) {
    const zoomDir = path.join(outputDir, zoom.toString());
    if (fs.existsSync(zoomDir)) {
      const xDirs = fs.readdirSync(zoomDir);
      for (const xDir of xDirs) {
        const xPath = path.join(zoomDir, xDir);
        if (fs.statSync(xPath).isDirectory()) {
          const yFiles = fs.readdirSync(xPath);
          for (const yFile of yFiles) {
            if (yFile.endsWith('.json')) {
              const y = yFile.replace('.json', '');
              const tileKey = `${zoom}/${xDir}/${y}`;
              const tilePath = path.join(xPath, yFile);
              const tileData = JSON.parse(fs.readFileSync(tilePath, 'utf-8'));
              allTiles.set(tileKey, tileData.features);
            }
          }
        }
      }
    }
  }

  const tileIndex = createTileIndex(allTiles);
  fs.writeFileSync(indexPath, JSON.stringify(tileIndex, null, 2));

  const endTime = Date.now();
  const duration = ((endTime - startTime) / 1000).toFixed(2);

  console.log('\n===========================');
  console.log('✅ Tiling Complete!');
  console.log('===========================');
  console.log(`📁 Output directory: ${outputDir}`);
  console.log(`📇 Index file: ${indexPath}`);
  console.log(`⏱️  Duration: ${duration} seconds`);
  console.log(`🗺️  Zoom levels: ${zoomLevels.join(', ')}`);
  console.log(`📦 Total tiles created: ${allTiles.size.toLocaleString()}\n`);
}

// Run tiling
tileBuildings().catch(error => {
  console.error('❌ Fatal error:', error);
  process.exit(1);
});
