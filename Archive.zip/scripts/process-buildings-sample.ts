#!/usr/bin/env node
/**
 * Sample Building Processing Script
 *
 * Processes only the first 1000 buildings for quick testing
 */

import * as fs from 'fs';
import * as path from 'path';
import proj4 from 'proj4';
import bbox from '@turf/bbox';
import {chain} from 'stream-chain';
import {parser} from 'stream-json';
import {pick} from 'stream-json/filters/Pick';
import {streamArray} from 'stream-json/streamers/StreamArray';

proj4.defs('EPSG:2326', '+proj=tmerc +lat_0=22.31213333333334 +lon_0=114.1785555555556 +k=1 +x_0=836694.05 +y_0=819069.8 +ellps=intl +towgs84=-162.619,-276.959,-161.764,0.067753,-2.24365,-1.15883,-1.09425 +units=m +no_defs');

const fromProjection = 'EPSG:2326';
const toProjection = 'EPSG:4326';

const CATEGORY_COLORS: Record<string, string> = {
  '1': '#3b82f6',
  '2': '#f97316',
  '3': '#6b7280',
  'default': '#d1d5db'
};

const ZOOM_LEVELS = [15, 16, 17, 18];
const SAMPLE_SIZE = 1000; // Only process first 1000 buildings

interface BuildingProperties {
  OBJECTID: number;
  BUILDINGSTRUCTUREID: number;
  CATEGORY: string;
  NUMABOVEGROUNDSTOREYS?: number | null;
  TOPHEIGHT?: number | null;
  [key: string]: any;
}

interface ConvertedFeature {
  type: 'Feature';
  geometry: {
    type: 'Polygon' | 'MultiPolygon';
    coordinates: number[][][] | number[][][][];
  };
  properties: BuildingProperties & {
    height_m: number;
    color: string;
  };
}

const tiles: Map<string, Map<string, ConvertedFeature[]>> = new Map();

for (const zoom of ZOOM_LEVELS) {
  tiles.set(zoom.toString(), new Map());
}

function convertCoordinates(coords: number[][]): number[][] {
  return coords.map(([x, y]) => {
    const [lng, lat] = proj4(fromProjection, toProjection, [x, y]);
    return [lng, lat];
  });
}

function convertPolygonCoordinates(coordinates: number[][][] | number[][][][], isMultiPolygon: boolean): number[][][] | number[][][][] {
  if (isMultiPolygon) {
    return (coordinates as number[][][][]).map(polygon =>
      polygon.map(ring => convertCoordinates(ring))
    );
  } else {
    return (coordinates as number[][][]).map(ring => convertCoordinates(ring));
  }
}

function calculateHeight(properties: BuildingProperties): number {
  if (properties.TOPHEIGHT !== null && properties.TOPHEIGHT !== undefined && properties.TOPHEIGHT > 0) {
    return properties.TOPHEIGHT;
  }
  if (properties.NUMABOVEGROUNDSTOREYS !== null && properties.NUMABOVEGROUNDSTOREYS !== undefined && properties.NUMABOVEGROUNDSTOREYS > 0) {
    return properties.NUMABOVEGROUNDSTOREYS * 3.5;
  }
  return 5;
}

function getCategoryColor(category: string): string {
  return CATEGORY_COLORS[category] || CATEGORY_COLORS.default;
}

function latLngToTile(lat: number, lng: number, zoom: number): { x: number; y: number } {
  const n = Math.pow(2, zoom);
  const x = Math.floor(((lng + 180) / 360) * n);
  const latRad = (lat * Math.PI) / 180;
  const y = Math.floor(((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) * n);
  return { x, y };
}

function getBuildingTiles(feature: ConvertedFeature, zoom: number): string[] {
  const featureBbox = bbox(feature);
  const [minLng, minLat, maxLng, maxLat] = featureBbox;

  const minTile = latLngToTile(maxLat, minLng, zoom);
  const maxTile = latLngToTile(minLat, maxLng, zoom);

  const tileKeys: string[] = [];

  for (let x = minTile.x; x <= maxTile.x; x++) {
    for (let y = minTile.y; y <= maxTile.y; y++) {
      tileKeys.push(`${x}/${y}`);
    }
  }

  return tileKeys;
}

function addFeatureToTiles(feature: ConvertedFeature) {
  for (const zoom of ZOOM_LEVELS) {
    const tileKeys = getBuildingTiles(feature, zoom);
    const zoomTiles = tiles.get(zoom.toString())!;

    for (const tileKey of tileKeys) {
      if (!zoomTiles.has(tileKey)) {
        zoomTiles.set(tileKey, []);
      }
      zoomTiles.get(tileKey)!.push(feature);
    }
  }
}

function writeTiles(outputDir: string) {
  console.log('\n💾 Writing sample tiles...');

  let totalTiles = 0;

  for (const [zoom, zoomTiles] of tiles.entries()) {
    console.log(`   Zoom ${zoom}: ${zoomTiles.size} tiles`);

    for (const [tileKey, features] of zoomTiles.entries()) {
      const [x, y] = tileKey.split('/');
      const tilePath = path.join(outputDir, zoom, x);
      const tileFile = path.join(tilePath, `${y}.json`);

      if (!fs.existsSync(tilePath)) {
        fs.mkdirSync(tilePath, { recursive: true });
      }

      const tileGeoJSON = {
        type: 'FeatureCollection',
        tile: { z: Number(zoom), x: Number(x), y: Number(y) },
        count: features.length,
        features: features
      };

      fs.writeFileSync(tileFile, JSON.stringify(tileGeoJSON));
      totalTiles++;
    }

    console.log(`   ✅ Wrote ${zoomTiles.size} tiles for zoom ${zoom}`);
  }

  console.log(`\n✅ Total sample tiles: ${totalTiles}`);
}

async function processBuildings() {
  console.log('🏗️  Sample Building Processing (First 1000)');
  console.log('===========================================\n');

  const inputPath = path.join(process.cwd(), 'Building_GEOJSON/Building_Footprint_Public_20251017.gdb_BUILDING_STRUCTURE_converted.json');
  const outputDir = path.join(process.cwd(), 'public/buildings/tiles');

  if (!fs.existsSync(inputPath)) {
    console.error('❌ Input file not found');
    process.exit(1);
  }

  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  console.log('📖 Processing sample buildings...\n');
  const startTime = Date.now();

  let featureCount = 0;

  const pipeline = chain([
    fs.createReadStream(inputPath),
    parser(),
    pick({filter: 'features'}),
    streamArray(),
  ]);

  for await (const {value: feature} of pipeline) {
    if (featureCount >= SAMPLE_SIZE) {
      break;
    }

    try {
      const isMultiPolygon = feature.geometry.type === 'MultiPolygon';

      const convertedFeature: ConvertedFeature = {
        type: 'Feature',
        geometry: {
          type: feature.geometry.type,
          coordinates: convertPolygonCoordinates(feature.geometry.coordinates, isMultiPolygon)
        },
        properties: {
          ...feature.properties,
          height_m: calculateHeight(feature.properties),
          color: getCategoryColor(feature.properties.CATEGORY)
        }
      };

      addFeatureToTiles(convertedFeature);
      featureCount++;

      if (featureCount % 100 === 0) {
        console.log(`   Processed ${featureCount} buildings...`);
      }
    } catch (error) {
      console.error(`Failed:`, error);
    }
  }

  console.log(`\n✅ Processed ${featureCount} sample buildings\n`);

  writeTiles(outputDir);

  const duration = ((Date.now() - startTime) / 1000).toFixed(2);

  console.log('\n===========================================');
  console.log('✅ Sample Processing Complete!');
  console.log('===========================================');
  console.log(`📁 Output: ${outputDir}`);
  console.log(`⏱️  Duration: ${duration}s`);
  console.log(`🏢 Buildings: ${featureCount.toLocaleString()}\n`);
}

processBuildings().catch(error => {
  console.error('❌ Fatal error:', error);
  process.exit(1);
});
