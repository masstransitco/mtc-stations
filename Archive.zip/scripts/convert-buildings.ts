#!/usr/bin/env node
/**
 * Building Data Preprocessing Script
 *
 * Converts Hong Kong building footprints from EPSG:2326 to EPSG:4326 (WGS84)
 * and normalizes height data for 3D rendering on Google Maps.
 *
 * Input: Building_GEOJSON/Building_Footprint_Public_20251017.gdb_BUILDING_STRUCTURE_converted.json
 * Output: public/buildings/converted-buildings.json
 */

import * as fs from 'fs';
import * as path from 'path';
import proj4 from 'proj4';
import { feature, featureCollection } from '@turf/helpers';

// Define coordinate systems
// EPSG:2326 - Hong Kong 1980 Grid System
proj4.defs('EPSG:2326', '+proj=tmerc +lat_0=22.31213333333334 +lon_0=114.1785555555556 +k=1 +x_0=836694.05 +y_0=819069.8 +ellps=intl +towgs84=-162.619,-276.959,-161.764,0.067753,-2.24365,-1.15883,-1.09425 +units=m +no_defs');

// EPSG:4326 - WGS84 (latitude/longitude)
const fromProjection = 'EPSG:2326';
const toProjection = 'EPSG:4326';

// Category to color mapping
const CATEGORY_COLORS: Record<string, string> = {
  '1': '#3b82f6',  // Residential - Blue
  '2': '#f97316',  // Commercial - Orange
  '3': '#6b7280',  // Industrial - Gray
  'default': '#d1d5db'  // Other - Light Gray
};

interface BuildingProperties {
  OBJECTID: number;
  BUILDINGSTRUCTUREID: number;
  BUILDINGCSUID: string;
  BUILDINGSTRUCTURETYPE: string;
  CATEGORY: string;
  STATUS: string;
  OFFICIALBUILDINGNAMEEN?: string;
  OFFICIALBUILDINGNAMETC?: string;
  NUMABOVEGROUNDSTOREYS?: number | null;
  NUMBASEMENTSTOREYS?: number | null;
  TOPHEIGHT?: number | null;
  BASEHEIGHT?: number | null;
  GROSSFLOORAREA?: number | null;
  SHAPE_Length: number;
  SHAPE_Area: number;
  RECORDCREATIONDATE: string;
  RECORDUPDATEDDATE: string;
}

interface ConvertedProperties extends BuildingProperties {
  height_m: number;
  color: string;
}

interface GeoJSONFeature {
  type: 'Feature';
  geometry: {
    type: 'Polygon' | 'MultiPolygon';
    coordinates: number[][][] | number[][][][];
  };
  properties: BuildingProperties;
}

interface ConvertedFeature {
  type: 'Feature';
  geometry: {
    type: 'Polygon' | 'MultiPolygon';
    coordinates: number[][][] | number[][][][];
  };
  properties: ConvertedProperties;
}

/**
 * Convert coordinates from EPSG:2326 to EPSG:4326
 */
function convertCoordinates(coords: number[][]): number[][] {
  return coords.map(([x, y]) => {
    const [lng, lat] = proj4(fromProjection, toProjection, [x, y]);
    return [lng, lat];
  });
}

/**
 * Recursively convert polygon coordinates
 */
function convertPolygonCoordinates(coordinates: number[][][] | number[][][][], isMultiPolygon: boolean): number[][][] | number[][][][] {
  if (isMultiPolygon) {
    // MultiPolygon: array of polygons
    return (coordinates as number[][][][]).map(polygon =>
      polygon.map(ring => convertCoordinates(ring))
    );
  } else {
    // Polygon: array of rings
    return (coordinates as number[][][]).map(ring => convertCoordinates(ring));
  }
}

/**
 * Calculate building height in meters
 * Priority: TOPHEIGHT > (NUMABOVEGROUNDSTOREYS * 3.5) > 5m default
 */
function calculateHeight(properties: BuildingProperties): number {
  // Priority 1: Use TOPHEIGHT if available
  if (properties.TOPHEIGHT !== null && properties.TOPHEIGHT !== undefined && properties.TOPHEIGHT > 0) {
    return properties.TOPHEIGHT;
  }

  // Priority 2: Estimate from number of storeys (3.5m per floor average)
  if (properties.NUMABOVEGROUNDSTOREYS !== null && properties.NUMABOVEGROUNDSTOREYS !== undefined && properties.NUMABOVEGROUNDSTOREYS > 0) {
    return properties.NUMABOVEGROUNDSTOREYS * 3.5;
  }

  // Default: Assume minimum 5 meters (1-2 storeys)
  return 5;
}

/**
 * Get color based on building category
 */
function getCategoryColor(category: string): string {
  return CATEGORY_COLORS[category] || CATEGORY_COLORS.default;
}

/**
 * Convert a single building feature
 */
function convertFeature(feature: GeoJSONFeature): ConvertedFeature {
  const isMultiPolygon = feature.geometry.type === 'MultiPolygon';

  return {
    type: 'Feature',
    geometry: {
      type: feature.geometry.type,
      coordinates: convertPolygonCoordinates(feature.geometry.coordinates, isMultiPolygon)
    },
    properties: {
      ...feature.properties,
      height_m: calculateHeight(feature.properties),
      color: getCategoryColor(feature.properties.CATEGORY)
    }
  };
}

/**
 * Main conversion function
 */
async function convertBuildings() {
  console.log('🏗️  Building Data Conversion Started');
  console.log('=====================================\n');

  // Paths
  const inputPath = path.join(process.cwd(), 'Building_GEOJSON/Building_Footprint_Public_20251017.gdb_BUILDING_STRUCTURE_converted.json');
  const outputDir = path.join(process.cwd(), 'public/buildings');
  const outputPath = path.join(outputDir, 'converted-buildings.json');

  // Check input file exists
  if (!fs.existsSync(inputPath)) {
    console.error('❌ Error: Input file not found at:', inputPath);
    process.exit(1);
  }

  // Create output directory if it doesn't exist
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
    console.log('✅ Created output directory:', outputDir);
  }

  console.log('📖 Reading input file...');
  const startTime = Date.now();

  // Read input file
  const inputData = fs.readFileSync(inputPath, 'utf-8');
  const geojson = JSON.parse(inputData);

  console.log(`✅ Loaded ${geojson.features.length.toLocaleString()} buildings\n`);

  console.log('🔄 Converting coordinates and calculating heights...');

  // Convert features
  const convertedFeatures: ConvertedFeature[] = [];
  let processedCount = 0;
  const totalFeatures = geojson.features.length;

  for (const feature of geojson.features) {
    try {
      convertedFeatures.push(convertFeature(feature));
      processedCount++;

      // Progress update every 10k features
      if (processedCount % 10000 === 0) {
        const progress = ((processedCount / totalFeatures) * 100).toFixed(1);
        console.log(`   Progress: ${processedCount.toLocaleString()} / ${totalFeatures.toLocaleString()} (${progress}%)`);
      }
    } catch (error) {
      console.error(`⚠️  Warning: Failed to convert feature ${feature.properties?.OBJECTID || 'unknown'}:`, error);
    }
  }

  console.log(`\n✅ Converted ${convertedFeatures.length.toLocaleString()} buildings successfully\n`);

  // Create output GeoJSON
  const outputGeoJSON = {
    type: 'FeatureCollection',
    name: 'BUILDING_STRUCTURE_WGS84',
    crs: {
      type: 'name',
      properties: {
        name: 'EPSG:4326'
      }
    },
    metadata: {
      originalCRS: 'EPSG:2326',
      convertedCRS: 'EPSG:4326',
      conversionDate: new Date().toISOString(),
      totalBuildings: convertedFeatures.length,
      heightMethod: 'TOPHEIGHT > (NUMABOVEGROUNDSTOREYS * 3.5m) > 5m default'
    },
    features: convertedFeatures
  };

  // Write output file
  console.log('💾 Writing output file...');
  fs.writeFileSync(outputPath, JSON.stringify(outputGeoJSON, null, 2));

  const endTime = Date.now();
  const duration = ((endTime - startTime) / 1000).toFixed(2);
  const fileSize = (fs.statSync(outputPath).size / (1024 * 1024)).toFixed(2);

  console.log('\n=====================================');
  console.log('✅ Conversion Complete!');
  console.log('=====================================');
  console.log(`📁 Output file: ${outputPath}`);
  console.log(`📦 File size: ${fileSize} MB`);
  console.log(`⏱️  Duration: ${duration} seconds`);
  console.log(`🏢 Buildings processed: ${convertedFeatures.length.toLocaleString()}\n`);
}

// Run conversion
convertBuildings().catch(error => {
  console.error('❌ Fatal error:', error);
  process.exit(1);
});
