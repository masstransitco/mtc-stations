#!/usr/bin/env node
/**
 * Combined Building Processing Script
 *
 * Converts Hong Kong building footprints from EPSG:2326 to EPSG:4326 (WGS84)
 * and writes directly to zoom-based tiles to avoid memory issues.
 *
 * Input: Building_GEOJSON/Building_Footprint_Public_20251017.gdb_BUILDING_STRUCTURE_converted.json
 * Output: public/buildings/tiles/{z}/{x}/{y}.json
 */

import * as fs from 'fs';
import * as path from 'path';
import * as readline from 'readline';
import proj4 from 'proj4';
import bbox from '@turf/bbox';

// Define coordinate systems
proj4.defs('EPSG:2326', '+proj=tmerc +lat_0=22.31213333333334 +lon_0=114.1785555555556 +k=1 +x_0=836694.05 +y_0=819069.8 +ellps=intl +towgs84=-162.619,-276.959,-161.764,0.067753,-2.24365,-1.15883,-1.09425 +units=m +no_defs');

const fromProjection = 'EPSG:2326';
const toProjection = 'EPSG:4326';

// Category to color mapping
const CATEGORY_COLORS: Record<string, string> = {
  '1': '#3b82f6',  // Residential - Blue
  '2': '#f97316',  // Commercial - Orange
  '3': '#6b7280',  // Industrial - Gray
  'default': '#d1d5db'  // Other - Light Gray
};

// Zoom levels to generate tiles for
const ZOOM_LEVELS = [15, 16, 17, 18];

interface BuildingProperties {
  OBJECTID: number;
  BUILDINGSTRUCTUREID: number;
  BUILDINGCSUID: string;
  BUILDINGSTRUCTURETYPE: string;
  CATEGORY: string;
  STATUS: string;
  OFFICIALBUILDINGNAMEEN?: string;
  OFFICIALBUILDINGNAMETC?: string;
  NUMABOVEGROUNDSTOREYS?: number | null;
  NUMBASEMENTSTOREYS?: number | null;
  TOPHEIGHT?: number | null;
  BASEHEIGHT?: number | null;
  GROSSFLOORAREA?: number | null;
  SHAPE_Length: number;
  SHAPE_Area: number;
}

interface ConvertedProperties extends BuildingProperties {
  height_m: number;
  color: string;
}

interface GeoJSONFeature {
  type: 'Feature';
  geometry: {
    type: 'Polygon' | 'MultiPolygon';
    coordinates: number[][][] | number[][][][];
  };
  properties: BuildingProperties;
}

interface ConvertedFeature {
  type: 'Feature';
  geometry: {
    type: 'Polygon' | 'MultiPolygon';
    coordinates: number[][][] | number[][][][];
  };
  properties: ConvertedProperties;
}

// In-memory tile storage
const tiles: Map<string, Map<string, ConvertedFeature[]>> = new Map();

// Initialize tiles map for each zoom level
for (const zoom of ZOOM_LEVELS) {
  tiles.set(zoom.toString(), new Map());
}

/**
 * Convert coordinates from EPSG:2326 to EPSG:4326
 */
function convertCoordinates(coords: number[][]): number[][] {
  return coords.map(([x, y]) => {
    const [lng, lat] = proj4(fromProjection, toProjection, [x, y]);
    return [lng, lat];
  });
}

/**
 * Recursively convert polygon coordinates
 */
function convertPolygonCoordinates(coordinates: number[][][] | number[][][][], isMultiPolygon: boolean): number[][][] | number[][][][] {
  if (isMultiPolygon) {
    return (coordinates as number[][][][]).map(polygon =>
      polygon.map(ring => convertCoordinates(ring))
    );
  } else {
    return (coordinates as number[][][]).map(ring => convertCoordinates(ring));
  }
}

/**
 * Calculate building height in meters
 */
function calculateHeight(properties: BuildingProperties): number {
  if (properties.TOPHEIGHT !== null && properties.TOPHEIGHT !== undefined && properties.TOPHEIGHT > 0) {
    return properties.TOPHEIGHT;
  }

  if (properties.NUMABOVEGROUNDSTOREYS !== null && properties.NUMABOVEGROUNDSTOREYS !== undefined && properties.NUMABOVEGROUNDSTOREYS > 0) {
    return properties.NUMABOVEGROUNDSTOREYS * 3.5;
  }

  return 5;
}

/**
 * Get color based on building category
 */
function getCategoryColor(category: string): string {
  return CATEGORY_COLORS[category] || CATEGORY_COLORS.default;
}

/**
 * Convert lat/lng to tile coordinates
 */
function latLngToTile(lat: number, lng: number, zoom: number): { x: number; y: number } {
  const n = Math.pow(2, zoom);
  const x = Math.floor(((lng + 180) / 360) * n);
  const latRad = (lat * Math.PI) / 180;
  const y = Math.floor(((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) * n);
  return { x, y };
}

/**
 * Get all tiles that a building intersects
 */
function getBuildingTiles(feature: ConvertedFeature, zoom: number): string[] {
  const featureBbox = bbox(feature);
  const [minLng, minLat, maxLng, maxLat] = featureBbox;

  const minTile = latLngToTile(maxLat, minLng, zoom);
  const maxTile = latLngToTile(minLat, maxLng, zoom);

  const tileKeys: string[] = [];

  for (let x = minTile.x; x <= maxTile.x; x++) {
    for (let y = minTile.y; y <= maxTile.y; y++) {
      tileKeys.push(`${x}/${y}`);
    }
  }

  return tileKeys;
}

/**
 * Add feature to tiles
 */
function addFeatureToTiles(feature: ConvertedFeature) {
  for (const zoom of ZOOM_LEVELS) {
    const tileKeys = getBuildingTiles(feature, zoom);
    const zoomTiles = tiles.get(zoom.toString())!;

    for (const tileKey of tileKeys) {
      if (!zoomTiles.has(tileKey)) {
        zoomTiles.set(tileKey, []);
      }
      zoomTiles.get(tileKey)!.push(feature);
    }
  }
}

/**
 * Write tiles to disk
 */
function writeTiles(outputDir: string) {
  console.log('\n💾 Writing tiles to disk...');

  let totalTiles = 0;

  for (const [zoom, zoomTiles] of tiles.entries()) {
    console.log(`\n   Zoom ${zoom}: ${zoomTiles.size} tiles`);

    let written = 0;

    for (const [tileKey, features] of zoomTiles.entries()) {
      const [x, y] = tileKey.split('/');
      const tilePath = path.join(outputDir, zoom, x);
      const tileFile = path.join(tilePath, `${y}.json`);

      // Create directory
      if (!fs.existsSync(tilePath)) {
        fs.mkdirSync(tilePath, { recursive: true });
      }

      // Create tile GeoJSON
      const tileGeoJSON = {
        type: 'FeatureCollection',
        tile: { z: Number(zoom), x: Number(x), y: Number(y) },
        count: features.length,
        features: features
      };

      // Write tile
      fs.writeFileSync(tileFile, JSON.stringify(tileGeoJSON));
      written++;
      totalTiles++;

      if (written % 100 === 0) {
        console.log(`      ${written} / ${zoomTiles.size} tiles`);
      }
    }

    console.log(`   ✅ Wrote ${written} tiles for zoom ${zoom}`);
  }

  console.log(`\n✅ Total tiles written: ${totalTiles}`);
}

/**
 * Process buildings from input file
 */
async function processBuildings() {
  console.log('🏗️  Building Processing Started');
  console.log('================================\n');

  const inputPath = path.join(process.cwd(), 'Building_GEOJSON/Building_Footprint_Public_20251017.gdb_BUILDING_STRUCTURE_converted.json');
  const outputDir = path.join(process.cwd(), 'public/buildings/tiles');

  if (!fs.existsSync(inputPath)) {
    console.error('❌ Error: Input file not found at:', inputPath);
    process.exit(1);
  }

  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
    console.log('✅ Created output directory:', outputDir);
  }

  console.log('📖 Reading and processing buildings...\n');
  const startTime = Date.now();

  // Read file line by line to avoid loading entire file into memory
  const fileStream = fs.createReadStream(inputPath);
  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity
  });

  let buffer = '';
  let featureCount = 0;
  let inFeatures = false;

  for await (const line of rl) {
    // Skip until we find the features array
    if (!inFeatures) {
      if (line.trim().startsWith('"features"')) {
        inFeatures = true;
      }
      continue;
    }

    // Accumulate feature JSON
    buffer += line;

    // Check if we have a complete feature
    if (line.trim() === '},' || line.trim() === '}') {
      // Remove trailing comma
      const featureJSON = buffer.replace(/,$/, '');

      try {
        const feature: GeoJSONFeature = JSON.parse(featureJSON);

        // Convert feature
        const isMultiPolygon = feature.geometry.type === 'MultiPolygon';
        const convertedFeature: ConvertedFeature = {
          type: 'Feature',
          geometry: {
            type: feature.geometry.type,
            coordinates: convertPolygonCoordinates(feature.geometry.coordinates, isMultiPolygon)
          },
          properties: {
            ...feature.properties,
            height_m: calculateHeight(feature.properties),
            color: getCategoryColor(feature.properties.CATEGORY)
          }
        };

        // Add to tiles
        addFeatureToTiles(convertedFeature);

        featureCount++;

        if (featureCount % 1000 === 0) {
          console.log(`   Processed ${featureCount.toLocaleString()} buildings...`);
        }
      } catch (error) {
        // Skip invalid features
      }

      buffer = '';
    }
  }

  console.log(`\n✅ Processed ${featureCount.toLocaleString()} buildings\n`);

  // Write all tiles to disk
  writeTiles(outputDir);

  const endTime = Date.now();
  const duration = ((endTime - startTime) / 1000).toFixed(2);

  console.log('\n================================');
  console.log('✅ Processing Complete!');
  console.log('================================');
  console.log(`📁 Output directory: ${outputDir}`);
  console.log(`⏱️  Duration: ${duration} seconds`);
  console.log(`🏢 Buildings processed: ${featureCount.toLocaleString()}\n`);
}

// Run processing
processBuildings().catch(error => {
  console.error('❌ Fatal error:', error);
  process.exit(1);
});
