#!/bin/bash
BUCKET="mtc-buildings-tiles"
BASE_DIR="public/buildings"
TOTAL=$(find $BASE_DIR/tiles -type f -name "*.json" | wc -l | tr -d ' ')
COUNT=0

echo "Starting upload of $TOTAL tiles to R2..."
echo ""

find $BASE_DIR/tiles -type f -name "*.json" | while read file; do
  RELATIVE_PATH="${file#$BASE_DIR/}"
  wrangler r2 object put "$BUCKET/$RELATIVE_PATH" --file="$file" > /dev/null 2>&1
  COUNT=$((COUNT + 1))
  
  if [ $((COUNT % 500)) -eq 0 ]; then
    PERCENT=$((COUNT * 100 / TOTAL))
    echo "Progress: $COUNT/$TOTAL ($PERCENT%)"
  fi
done

echo ""
echo "Upload complete! Uploaded $TOTAL files."
