import SimpleMap from "@/components/simple-map";

export default function Home() {
  return <SimpleMap />;
}
